USE JDV;

INSERT INTO jogadores(JOGD_NOME)
value
(null),
(null);

INSERT INTO jogo (JOG_JOGD_1, JOG_JOGD_2)
values(1,2);

INSERT INTO tabuleiro(TAB_JOG_JOGD_1, TAB_JOG_JOGD_2, TAB_POSICAO)
values
(1,2,'a1'),
(1,2,'a2'),
(1,2,'a3'),
(1,2,'b1'),
(1,2,'b2'),
(1,2,'b3'),
(1,2,'c1'),
(1,2,'c2'),
(1,2,'c3');

